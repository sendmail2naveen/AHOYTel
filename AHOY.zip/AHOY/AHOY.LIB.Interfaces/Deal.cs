﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AHOYTEL.LIB.Models
{
    public class Deal
    {
        public string Name { get; set; }
        public int Sequence { get; set; }
        public double Discount { get; set; }
        public string Description { get; set; }
    }
}

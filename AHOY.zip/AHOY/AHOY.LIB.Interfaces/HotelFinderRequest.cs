﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AHOYTEL.LIB.Models
{
    public class HotelFinderRequest : BaseRequest
    {
        public string HotelId { get; set; }
    }
}

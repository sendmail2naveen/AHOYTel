﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AHOYTEL.LIB.Models
{
    public class Facility
    {
        public string FacilityName { get; set; }
        public string FacilityDesc { get; set; }
        public byte[] FacilityImage { get; set; }
    }
}
